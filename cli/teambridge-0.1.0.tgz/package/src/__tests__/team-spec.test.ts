import { describe, it, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import * as fs from "node:fs";
import * as path from "node:path";
import * as os from "node:os";
import { readTeamSpec, writeTeamSpec, validateTeamSpec } from "../team-spec.js";
import type { TeamSpec } from "../team-spec.js";

function makeTmpDir(): string {
  return fs.mkdtempSync(path.join(os.tmpdir(), "team-spec-test-"));
}

const validSpec: TeamSpec = {
  name: "fraudstory",
  agents: [
    { name: "architect", role: "Design system architecture" },
    { name: "implementer", role: "Write production code" },
    { name: "reviewer", role: "Review correctness and security" },
  ],
};

describe("validateTeamSpec", () => {
  it("accepts a valid spec", () => {
    const errors = validateTeamSpec(validSpec);
    assert.equal(errors.length, 0);
  });

  it("rejects null", () => {
    const errors = validateTeamSpec(null);
    assert.equal(errors.length, 1);
    assert.match(errors[0]!.message, /must be an object/);
  });

  it("rejects missing name", () => {
    const errors = validateTeamSpec({ agents: [{ name: "a", role: "r" }] });
    assert.ok(errors.some((e) => e.path === "name"));
  });

  it("rejects invalid name characters", () => {
    const errors = validateTeamSpec({ name: "My Team!", agents: [{ name: "a", role: "r" }] });
    assert.ok(errors.some((e) => e.path === "name" && e.message.includes("lowercase")));
  });

  it("rejects missing agents", () => {
    const errors = validateTeamSpec({ name: "team" });
    assert.ok(errors.some((e) => e.path === "agents"));
  });

  it("rejects empty agents array", () => {
    const errors = validateTeamSpec({ name: "team", agents: [] });
    assert.ok(errors.some((e) => e.path === "agents" && e.message.includes("at least one")));
  });

  it("rejects agent without name", () => {
    const errors = validateTeamSpec({ name: "team", agents: [{ role: "r" }] });
    assert.ok(errors.some((e) => e.path === "agents[0].name"));
  });

  it("rejects agent without role", () => {
    const errors = validateTeamSpec({ name: "team", agents: [{ name: "a" }] });
    assert.ok(errors.some((e) => e.path === "agents[0].role"));
  });

  it("rejects duplicate agent names", () => {
    const errors = validateTeamSpec({
      name: "team",
      agents: [
        { name: "a", role: "r1" },
        { name: "a", role: "r2" },
      ],
    });
    assert.ok(errors.some((e) => e.message.includes("duplicate")));
  });

  it("accepts agent with soul", () => {
    const errors = validateTeamSpec({
      name: "team",
      agents: [{ name: "a", role: "r", soul: "You are a helpful agent." }],
    });
    assert.equal(errors.length, 0);
  });

  it("rejects non-string soul", () => {
    const errors = validateTeamSpec({
      name: "team",
      agents: [{ name: "a", role: "r", soul: 42 }],
    });
    assert.ok(errors.some((e) => e.path === "agents[0].soul"));
  });
});

describe("readTeamSpec", () => {
  let tmpDir: string;

  beforeEach(() => {
    tmpDir = makeTmpDir();
  });

  afterEach(() => {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it("reads a valid agent-team.yaml", () => {
    const yaml = `name: fraudstory
agents:
  - name: architect
    role: Design system architecture
  - name: implementer
    role: Write production code
`;
    fs.writeFileSync(path.join(tmpDir, "agent-team.yaml"), yaml);

    const spec = readTeamSpec(tmpDir);
    assert.equal(spec.name, "fraudstory");
    assert.equal(spec.agents.length, 2);
    assert.equal(spec.agents[0]!.name, "architect");
    assert.equal(spec.agents[1]!.role, "Write production code");
  });

  it("reads multiline soul", () => {
    const yaml = `name: team1
agents:
  - name: bot
    role: Helper
    soul: |
      You are a helpful bot.
      Always be kind.
`;
    fs.writeFileSync(path.join(tmpDir, "agent-team.yaml"), yaml);

    const spec = readTeamSpec(tmpDir);
    assert.ok(spec.agents[0]!.soul!.includes("Always be kind."));
  });

  it("throws when file is missing", () => {
    assert.throws(() => readTeamSpec(tmpDir), /not found/);
  });

  it("throws on invalid YAML", () => {
    fs.writeFileSync(path.join(tmpDir, "agent-team.yaml"), "{{invalid");
    assert.throws(() => readTeamSpec(tmpDir), /Failed to parse/);
  });

  it("throws on schema errors", () => {
    fs.writeFileSync(path.join(tmpDir, "agent-team.yaml"), "name: 123\nagents: bad\n");
    assert.throws(() => readTeamSpec(tmpDir), /Invalid/);
  });
});

describe("writeTeamSpec", () => {
  let tmpDir: string;

  beforeEach(() => {
    tmpDir = makeTmpDir();
  });

  afterEach(() => {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it("writes and round-trips a spec", () => {
    writeTeamSpec(validSpec, tmpDir);
    const result = readTeamSpec(tmpDir);
    assert.deepEqual(result, validSpec);
  });

  it("creates agent-team.yaml file", () => {
    writeTeamSpec(validSpec, tmpDir);
    assert.ok(fs.existsSync(path.join(tmpDir, "agent-team.yaml")));
  });

  it("throws on invalid spec", () => {
    assert.throws(
      () => writeTeamSpec({ name: "", agents: [] } as TeamSpec, tmpDir),
      /Invalid/,
    );
  });

  it("preserves soul field in round-trip", () => {
    const specWithSoul: TeamSpec = {
      name: "team1",
      agents: [{ name: "bot", role: "Helper", soul: "You are a helpful bot.\nAlways be kind.\n" }],
    };
    writeTeamSpec(specWithSoul, tmpDir);
    const result = readTeamSpec(tmpDir);
    assert.equal(result.agents[0]!.soul, specWithSoul.agents[0]!.soul);
  });
});
