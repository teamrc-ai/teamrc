import * as fs from "node:fs";
import * as path from "node:path";
import * as os from "node:os";
import * as crypto from "node:crypto";
import { execFileSync } from "node:child_process";
import { readTeamSpec, writeTeamSpec } from "../team-spec.js";
import type { TeamSpec } from "../team-spec.js";
import type {
  PlatformAdapter,
  TeamDefinition,
} from "./base.js";

function hashContent(content: string): string {
  return crypto.createHash("sha256").update(content).digest("hex").slice(0, 16);
}

function toTeamDef(spec: TeamSpec): TeamDefinition {
  return {
    name: spec.name,
    members: spec.agents.map((a) => ({ name: a.name, role: a.role, soul: a.soul })),
  };
}

export class OpenClawAdapter implements PlatformAdapter {
  private openclawDir: string;

  constructor() {
    this.openclawDir = path.join(os.homedir(), ".openclaw");
  }

  /** Directory for a TeamBridge agent's workspace */
  private agentWorkspace(agentName: string): string {
    return path.join(this.openclawDir, "workspaces", `tb-${agentName}`);
  }

  readTeam(): TeamDefinition | null {
    try {
      const spec = readTeamSpec();
      return toTeamDef(spec);
    } catch {
      return null;
    }
  }

  writeTeam(team: TeamDefinition): void {
    // Write canonical agent-team.yaml
    const spec: TeamSpec = {
      name: team.name,
      agents: team.members.map((m) => ({
        name: m.name,
        role: m.role,
        ...(m.soul ? { soul: m.soul } : {}),
      })),
    };
    writeTeamSpec(spec);

    // Apply to platform-native format
    this.applyToNative(team);
  }

  private applyToNative(team: TeamDefinition): void {
    for (const member of team.members) {
      const agentName = `tb-${member.name}`;
      const workspaceDir = this.agentWorkspace(member.name);
      if (!fs.existsSync(workspaceDir)) {
        fs.mkdirSync(workspaceDir, { recursive: true });
      }

      // SOUL.md — persona definition (required by OpenClaw)
      const soulPath = path.join(workspaceDir, "SOUL.md");
      const soulContent = member.soul
        ? `# ${member.role}\n\n${member.soul}`
        : `# ${member.role}\n\nYou are ${member.name} on the ${team.name} team.\nRole: ${member.role}\n`;
      fs.writeFileSync(soulPath, soulContent);

      // AGENTS.md — operating instructions
      const agentsPath = path.join(workspaceDir, "AGENTS.md");
      const agentsContent = `# Team: ${team.name}\n\nYou are **${member.name}** — ${member.role}.\n\n## Teammates\n\n${team.members.map((m) => `- **${m.name}** — ${m.role}`).join("\n")}\n\n## Team Knowledge\n\nShared findings and decisions are stored in \`TEAM-KNOWLEDGE.md\` in the default workspace. Read it at the start of every session for context from other agents and machines. When you discover something important, append it to that file.\n`;
      fs.writeFileSync(agentsPath, agentsContent);

      // Register agent with OpenClaw via CLI
      try {
        execFileSync("openclaw", [
          "agents", "add", agentName,
          "--workspace", workspaceDir,
          "--non-interactive",
        ], {
          stdio: "ignore",
        });
      } catch {
        // CLI not available — register directly in openclaw.json
        this.registerAgentInConfig(agentName, workspaceDir);
      }
    }
  }

  private registerAgentInConfig(agentId: string, workspace: string): void {
    const configPath = path.join(this.openclawDir, "openclaw.json");
    let config: Record<string, unknown> = {};
    if (fs.existsSync(configPath)) {
      try {
        // JSON5 is a superset of JSON — standard JSON.parse works for most configs
        const raw = fs.readFileSync(configPath, "utf-8");
        // Strip single-line comments and trailing commas for basic JSON5 compat
        const cleaned = raw
          .replace(/\/\/.*$/gm, "")
          .replace(/,\s*([\]}])/g, "$1");
        config = JSON.parse(cleaned) as Record<string, unknown>;
      } catch {
        // Can't parse existing config — don't clobber it
        return;
      }
    }

    const agents = (config["agents"] ?? {}) as Record<string, unknown>;
    const list = (agents["list"] ?? []) as Array<{ id: string; workspace?: string }>;

    // Skip if agent already registered
    if (list.some((a) => a.id === agentId)) return;

    list.push({ id: agentId, workspace });
    agents["list"] = list;
    config["agents"] = agents;

    const dir = path.dirname(configPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    }
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  }

  private knowledgePath(): string {
    return path.join(this.openclawDir, "workspace", "TEAM-KNOWLEDGE.md");
  }

  readKnowledge(): string {
    const filePath = this.knowledgePath();
    if (!fs.existsSync(filePath)) {
      return "";
    }
    return fs.readFileSync(filePath, "utf-8");
  }

  writeKnowledge(content: string): void {
    const dir = path.dirname(this.knowledgePath());
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(this.knowledgePath(), content);
  }

  appendKnowledge(entries: string[]): void {
    if (entries.length === 0) return;

    const filePath = this.knowledgePath();
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    const newContent = entries
      .map((e) => `- ${new Date().toISOString().slice(0, 10)}: ${e}`)
      .join("\n");

    if (fs.existsSync(filePath)) {
      fs.appendFileSync(filePath, "\n" + newContent + "\n");
    } else {
      fs.writeFileSync(
        filePath,
        `# Team Knowledge\n\nShared findings and decisions synced by TeamBridge. Do not edit manually.\n\n${newContent}\n`,
      );
    }
  }

  getHashes(): Record<string, string> {
    const hashes: Record<string, string> = {};

    // Hash agent-team.yaml
    const teamFile = path.join(process.cwd(), "agent-team.yaml");
    if (fs.existsSync(teamFile)) {
      hashes["team-spec"] = hashContent(fs.readFileSync(teamFile, "utf-8"));
    }

    // Hash team knowledge file
    const knowledgePath = this.knowledgePath();
    if (fs.existsSync(knowledgePath)) {
      const content = fs.readFileSync(knowledgePath, "utf-8");
      hashes["knowledge:team"] = hashContent(content);
    }

    return hashes;
  }

  watchPaths(): string[] {
    return [
      path.join(process.cwd(), "agent-team.yaml"),
      this.knowledgePath(),
    ];
  }

  writeFile(key: string, content: string): void {
    const filePath = this.resolveFileKey(key);
    if (!filePath) return;
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(filePath, content);
  }

  readFile(key: string): string | null {
    const filePath = this.resolveFileKey(key);
    if (!filePath || !fs.existsSync(filePath)) return null;
    return fs.readFileSync(filePath, "utf-8");
  }

  private resolveFileKey(key: string): string | null {
    if (key === "team-spec") {
      return path.join(process.cwd(), "agent-team.yaml");
    }
    if (key === "knowledge:team") {
      return this.knowledgePath();
    }
    return null;
  }

  installHooks(relay: string, _token: string): void {
    const hookDir = path.join(
      this.openclawDir,
      "hooks",
      "teambridge-sync",
    );
    if (!fs.existsSync(hookDir)) {
      fs.mkdirSync(hookDir, { recursive: true });
    }

    const hookPath = path.join(hookDir, "index.ts");
    const hookContent = `// TeamBridge sync hook for OpenClaw
// Runs on session start to sync team state

import { execFileSync } from "node:child_process";

export default function teambridgeSync() {
  try {
    execFileSync("npx", ["teambridge", "sync"], {
      stdio: "ignore",
      env: {
        ...process.env,
        TEAMBRIDGE_RELAY: "${relay}",
      },
    });
  } catch {
    // Sync failures are non-fatal
  }
}
`;
    fs.writeFileSync(hookPath, hookContent);

    // Note: OpenClaw hooks are discovered automatically from ~/.openclaw/hooks/
    // No config file update needed — OpenClaw scans the hooks directory.
  }
}
