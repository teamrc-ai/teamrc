import { createRequire } from "node:module";

export interface TeamMember {
  name: string;
  role: string;
  soul?: string;
}

export interface TeamDefinition {
  name: string;
  members: TeamMember[];
}

export type TeamScope = "project" | "global";

export interface PlatformAdapter {
  readTeam(): TeamDefinition | null;
  writeTeam(team: TeamDefinition, scope?: TeamScope): void;
  readKnowledge(): string;
  writeKnowledge(content: string): void;
  appendKnowledge(entries: string[]): void;
  getHashes(): Record<string, string>;
  installHooks(relay: string, token: string): void;
  watchPaths(): string[];
  writeFile(key: string, content: string): void;
  readFile(key: string): string | null;
}

export function getAdapter(platform: string): PlatformAdapter {
  const require = createRequire(import.meta.url);

  switch (platform) {
    case "claude-code": {
      const mod = require("./claude-code.js") as {
        ClaudeCodeAdapter: new () => PlatformAdapter;
      };
      return new mod.ClaudeCodeAdapter();
    }
    case "openclaw": {
      const mod = require("./openclaw.js") as {
        OpenClawAdapter: new () => PlatformAdapter;
      };
      return new mod.OpenClawAdapter();
    }
    default:
      throw new Error(`Unknown platform: ${platform}`);
  }
}
