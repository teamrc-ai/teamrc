import * as fs from "node:fs";
import * as path from "node:path";
import * as os from "node:os";
import * as crypto from "node:crypto";
import { readTeamSpec, writeTeamSpec } from "../team-spec.js";
import type { TeamSpec } from "../team-spec.js";
import type {
  PlatformAdapter,
  TeamDefinition,
  TeamMember,
  TeamScope,
} from "./base.js";

function hashContent(content: string): string {
  return crypto.createHash("sha256").update(content).digest("hex").slice(0, 16);
}

function toTeamDef(spec: TeamSpec): TeamDefinition {
  return {
    name: spec.name,
    members: spec.agents.map((a) => ({ name: a.name, role: a.role, soul: a.soul })),
  };
}

export class ClaudeCodeAdapter implements PlatformAdapter {
  private claudeDir: string;

  constructor() {
    this.claudeDir = path.join(os.homedir(), ".claude");
  }

  private agentsDir(scope: TeamScope): string {
    if (scope === "project") {
      return path.join(process.cwd(), ".claude", "agents");
    }
    return path.join(this.claudeDir, "agents");
  }

  readTeam(): TeamDefinition | null {
    try {
      const spec = readTeamSpec();
      return toTeamDef(spec);
    } catch {
      return null;
    }
  }

  writeTeam(team: TeamDefinition, scope: TeamScope = "global"): void {
    // Write canonical agent-team.yaml
    const spec: TeamSpec = {
      name: team.name,
      agents: team.members.map((m) => ({
        name: m.name,
        role: m.role,
        ...(m.soul ? { soul: m.soul } : {}),
      })),
    };
    writeTeamSpec(spec);

    // Apply to platform-native format
    this.applyToNative(team, scope);
  }

  private applyToNative(team: TeamDefinition, scope: TeamScope): void {
    const dir = this.agentsDir(scope);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    for (const member of team.members) {
      const fileName = `tb-${slugify(member.name)}.md`;
      const filePath = path.join(dir, fileName);
      const content = buildAgentFile(team.name, member);
      fs.writeFileSync(filePath, content);
    }

    this.updateClaudeMd(team, scope);
  }

  private updateClaudeMd(team: TeamDefinition, scope: TeamScope): void {
    const teamSection = buildClaudeMdSection(team);

    if (scope === "project") {
      const claudeMdPath = path.join(process.cwd(), "CLAUDE.md");
      if (!fs.existsSync(claudeMdPath)) {
        fs.writeFileSync(claudeMdPath, `# Project Configuration\n${teamSection}`);
      } else {
        const existing = fs.readFileSync(claudeMdPath, "utf-8");
        const cleaned = existing.replace(
          /\n## TeamBridge Team: .+?(?=\n## |\n# |$)/s,
          "",
        );
        fs.writeFileSync(claudeMdPath, cleaned.trimEnd() + "\n" + teamSection);
      }
    }
  }

  private knowledgePath(scope: TeamScope = "project"): string {
    if (scope === "project") {
      return path.join(process.cwd(), ".claude", "team-knowledge.md");
    }
    return path.join(this.claudeDir, "team-knowledge.md");
  }

  readKnowledge(): string {
    for (const scope of ["project", "global"] as TeamScope[]) {
      const filePath = this.knowledgePath(scope);
      if (fs.existsSync(filePath)) {
        return fs.readFileSync(filePath, "utf-8");
      }
    }
    return "";
  }

  writeKnowledge(content: string): void {
    const filePath = this.knowledgePath("project");
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(filePath, content);
  }

  appendKnowledge(entries: string[]): void {
    if (entries.length === 0) return;

    const filePath = this.knowledgePath("project");
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    const newContent = entries
      .map((e) => `- ${new Date().toISOString().slice(0, 10)}: ${e}`)
      .join("\n");

    if (fs.existsSync(filePath)) {
      fs.appendFileSync(filePath, "\n" + newContent + "\n");
    } else {
      fs.writeFileSync(
        filePath,
        `# Team Knowledge\n\nShared findings and decisions synced by TeamBridge. Do not edit manually.\n\n${newContent}\n`,
      );
    }
  }

  getHashes(): Record<string, string> {
    const hashes: Record<string, string> = {};

    // Hash agent-team.yaml
    const teamFile = path.join(process.cwd(), "agent-team.yaml");
    if (fs.existsSync(teamFile)) {
      hashes["team-spec"] = hashContent(fs.readFileSync(teamFile, "utf-8"));
    }

    // Hash team knowledge file
    for (const scope of ["project", "global"] as TeamScope[]) {
      const kPath = this.knowledgePath(scope);
      if (fs.existsSync(kPath)) {
        const content = fs.readFileSync(kPath, "utf-8");
        hashes[`knowledge:${scope}`] = hashContent(content);
      }
    }

    return hashes;
  }

  watchPaths(): string[] {
    return [
      path.join(process.cwd(), "agent-team.yaml"),
      this.knowledgePath("project"),
      this.knowledgePath("global"),
    ];
  }

  writeFile(key: string, content: string): void {
    const filePath = this.resolveFileKey(key);
    if (!filePath) return;
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(filePath, content);
  }

  readFile(key: string): string | null {
    const filePath = this.resolveFileKey(key);
    if (!filePath || !fs.existsSync(filePath)) return null;
    return fs.readFileSync(filePath, "utf-8");
  }

  private resolveFileKey(key: string): string | null {
    if (key === "team-spec") {
      return path.join(process.cwd(), "agent-team.yaml");
    }
    if (key === "knowledge:project") {
      return this.knowledgePath("project");
    }
    if (key === "knowledge:global") {
      return this.knowledgePath("global");
    }
    return null;
  }

  installHooks(relay: string, _token: string): void {
    const settingsPath = path.join(this.claudeDir, "settings.json");
    let settings: Record<string, unknown> = {};

    if (fs.existsSync(settingsPath)) {
      try {
        settings = JSON.parse(
          fs.readFileSync(settingsPath, "utf-8"),
        ) as Record<string, unknown>;
      } catch {
        // Start fresh if settings file is corrupted
      }
    }

    const hooks = (settings["hooks"] ?? {}) as Record<string, unknown>;
    const sessionStart = (hooks["SessionStart"] ?? []) as Array<{
      command: string;
    }>;

    const hookCommand = "npx teambridge sync 2>/dev/null || true";
    const alreadyInstalled = sessionStart.some(
      (h) => h.command === hookCommand,
    );

    if (!alreadyInstalled) {
      sessionStart.push({ command: hookCommand });
    }

    hooks["SessionStart"] = sessionStart;
    settings["hooks"] = hooks;

    if (!fs.existsSync(this.claudeDir)) {
      fs.mkdirSync(this.claudeDir, { recursive: true });
    }
    fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
  }
}

// --- Helpers ---

function slugify(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9-]/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

function buildAgentFile(teamName: string, member: TeamMember): string {
  const slug = slugify(member.name);
  const body = member.soul
    ? member.soul
    : `You are ${member.name}, a ${member.role} on the ${teamName} team.\n\nFocus on your role and collaborate with your teammates.`;

  return `---
name: ${slug}
description: "${member.role} on the ${teamName} team. Use when tasks relate to ${member.role.toLowerCase()}."
model: inherit
---

# Team: ${teamName}

${body}
`;
}

function buildClaudeMdSection(team: TeamDefinition): string {
  const memberLines = team.members
    .map((m) => `- **${m.name}** — ${m.role}`)
    .join("\n");

  return `
## TeamBridge Team: ${team.name}

This project has a synced agent team managed by TeamBridge.

Members:
${memberLines}

Each member is defined as a subagent in \`.claude/agents/\`. Delegate tasks to them based on their roles.

### Team Knowledge
Shared findings and decisions are stored in \`.claude/team-knowledge.md\`. Read this file at the start of every session for context from other agents and machines. When you discover something important (architecture decisions, gotchas, debugging insights), append it to this file so other team members can benefit.
`;
}
