#!/usr/bin/env node

import * as readline from "node:readline";
import { Command } from "commander";
import {
  generateKeypair,
  saveKeypair,
  loadKeypair,
  toToken,
} from "./auth.js";
import { RelayClient } from "./relay-client.js";
import {
  loadConfig,
  saveConfig,
  detectPlatform,
  detectPlatforms,
  getRelayUrl,
} from "./config.js";
import { getAdapter } from "./adapters/base.js";
import type { TeamScope } from "./adapters/base.js";
import { readTeamSpec, writeTeamSpec } from "./team-spec.js";
import type { TeamSpec } from "./team-spec.js";
import { resolveChange } from "./merge.js";

function askQuestion(question: string): Promise<string> {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  return new Promise((resolve) => {
    rl.question(question, (answer) => {
      rl.close();
      resolve(answer.trim());
    });
  });
}

async function askScope(platform: string): Promise<TeamScope> {
  if (platform !== "claude-code") {
    return "global";
  }

  console.log("\nWhere should this team be available?");
  console.log("  1) This project only (creates agents in .claude/agents/ and updates CLAUDE.md)");
  console.log("  2) All projects (creates agents in ~/.claude/agents/)");
  const answer = await askQuestion("\nChoice [1/2]: ");

  if (answer === "2") {
    return "global";
  }
  return "project";
}

async function requirePlatform(override?: string): Promise<string> {
  if (override) {
    const valid = ["claude-code", "openclaw"];
    if (!valid.includes(override)) {
      console.error(`Unknown platform: ${override}. Valid options: ${valid.join(", ")}`);
      process.exit(1);
    }
    return override;
  }
  const platforms = detectPlatforms();
  if (platforms.length === 0) {
    console.error(
      "Could not detect platform. Ensure ~/.claude or ~/.openclaw exists, or use --platform.",
    );
    process.exit(1);
  }
  if (platforms.length === 1) {
    return platforms[0];
  }

  // Multiple platforms detected — ask the user
  console.log("\nMultiple platforms detected:");
  for (let i = 0; i < platforms.length; i++) {
    console.log(`  ${i + 1}) ${platforms[i]}`);
  }
  console.log(`  ${platforms.length + 1}) Both`);
  const answer = await askQuestion(`\nWhich platform? [1-${platforms.length + 1}]: `);
  const choice = parseInt(answer, 10);
  if (choice >= 1 && choice <= platforms.length) {
    return platforms[choice - 1];
  }
  if (choice === platforms.length + 1) {
    return "both";
  }
  return platforms[0];
}

/** Get the first platform from a possibly comma-separated config value. */
function primaryPlatform(platformStr: string): string {
  return platformStr.split(",")[0];
}

async function requireKeypair() {
  let kp = loadKeypair();
  if (!kp) {
    kp = await generateKeypair();
    saveKeypair(kp);
    console.log("Generated new keypair.");
  }
  return kp;
}

const program = new Command();

program
  .name("teambridge")
  .description("TeamBridge — sync multi-agent teams across platforms")
  .version("0.1.0");

// --- init ---
program
  .command("init")
  .description("Initialize TeamBridge: detect platform, generate agent-team.yaml, connect to relay")
  .option("--relay <url>", "Relay server URL")
  .option("--platform <platform>", "Override platform detection (claude-code, openclaw)")
  .action(async (opts: { relay?: string; platform?: string }) => {
    const selected = await requirePlatform(opts.platform);
    const platforms = selected === "both" ? detectPlatforms() : [selected];

    const kp = await requireKeypair();
    const token = toToken(kp.publicKey);
    const relayUrl = getRelayUrl(opts.relay);

    // Try to read existing team from agent-team.yaml, fall back to first adapter
    let spec: TeamSpec;
    try {
      spec = readTeamSpec();
      console.log(`Found existing agent-team.yaml: team "${spec.name}" with ${spec.agents.length} agent(s).`);
    } catch {
      const adapter = getAdapter(platforms[0]);
      const existingTeam = adapter.readTeam();
      spec = {
        name: existingTeam?.name ?? "my-team",
        agents: existingTeam?.members.map((m) => ({
          name: m.name,
          role: m.role,
          ...(m.soul ? { soul: m.soul } : {}),
        })) ?? [],
      };

      if (spec.agents.length === 0) {
        console.log("No existing agents found. Creating a default agent-team.yaml.");
        spec.agents = [{ name: "agent", role: "General-purpose assistant" }];
      }

      writeTeamSpec(spec);
      console.log(`Generated agent-team.yaml with ${spec.agents.length} agent(s).`);
    }

    // Apply to each platform's native format
    for (const p of platforms) {
      console.log(`Setting up ${p}...`);
      const adapter = getAdapter(p);
      const scope = await askScope(p);
      adapter.writeTeam({
        name: spec.name,
        members: spec.agents.map((a) => ({ name: a.name, role: a.role, soul: a.soul })),
      }, scope);
      adapter.installHooks(relayUrl, token);
      console.log(`  ${p} configured.`);
    }

    // Create team on relay
    const client = new RelayClient(relayUrl, kp.privateKey, token);
    try {
      const relayTeam = await client.createTeam(
        spec.name,
        spec.agents.map((a) => ({ name: a.name, role: a.role, platform: platforms.join(",") })),
      );
      console.log(`Team created on relay: ${relayTeam.id}`);

      const firstAdapter = getAdapter(platforms[0]);
      const knowledge = firstAdapter.readKnowledge();
      if (knowledge) {
        await client.push(platforms[0], {
          type: "team-knowledge",
          content: knowledge,
        });
        console.log("Pushed team knowledge.");
      }

      saveConfig({
        platform: platforms.join(","),
        relay: relayUrl,
        token,
        teamId: relayTeam.id,
      });
      console.log("Configuration saved.");
      console.log(`\nShare this token to invite others: ${token}`);
    } catch (err) {
      console.error("Failed to initialize with relay:", err);
      saveConfig({ platform: platforms.join(","), relay: relayUrl, token });
      console.log("Configuration saved (relay unreachable).");
    }
  });

// --- join ---
program
  .command("join")
  .description("Join an existing team and create local agents")
  .argument("<token>", "Team invitation token")
  .option("--relay <url>", "Relay server URL")
  .option("--platform <platform>", "Override platform detection (claude-code, openclaw)")
  .option("--scope <scope>", "Team scope: project or global (skips prompt)")
  .action(async (joinToken: string, opts: { relay?: string; platform?: string; scope?: string }) => {
    const selected = await requirePlatform(opts.platform);
    const platforms = selected === "both" ? detectPlatforms() : [selected];

    const kp = await requireKeypair();
    const token = toToken(kp.publicKey);
    const relayUrl = getRelayUrl(opts.relay);
    const client = new RelayClient(relayUrl, kp.privateKey, token);

    try {
      const team = await client.joinByInvite(joinToken);
      console.log(`Joined team: ${team.name}`);

      // Write agent-team.yaml
      const spec: TeamSpec = {
        name: team.name,
        agents: team.members.map((m) => ({ name: m.name, role: m.role })),
      };
      writeTeamSpec(spec);
      console.log("Created agent-team.yaml.");

      // Apply to each platform's native format
      for (const p of platforms) {
        console.log(`Setting up ${p}...`);
        const adapter = getAdapter(p);
        const scope: TeamScope = opts.scope === "project" || opts.scope === "global"
          ? opts.scope
          : await askScope(p);
        adapter.writeTeam({
          name: team.name,
          members: team.members.map((m) => ({
            name: m.name,
            role: m.role,
          })),
        }, scope);
        adapter.installHooks(relayUrl, token);
        console.log(`  ${p} configured.`);
      }

      saveConfig({
        platform: platforms.join(","),
        relay: relayUrl,
        token,
        teamId: team.id,
      });
      console.log("Configuration saved.");
    } catch (err) {
      console.error("Failed to join team:", err);
      process.exit(1);
    }
  });

// --- apply ---
program
  .command("apply")
  .description("Apply agent-team.yaml to local platform (no relay needed)")
  .option("--platform <platform>", "Override platform detection (claude-code, openclaw)")
  .option("--scope <scope>", "Team scope: project or global")
  .action(async (opts: { platform?: string; scope?: string }) => {
    const selected = await requirePlatform(opts.platform);
    const platforms = selected === "both" ? detectPlatforms() : [selected];

    let spec: TeamSpec;
    try {
      spec = readTeamSpec();
    } catch (err) {
      console.error((err as Error).message);
      process.exit(1);
    }

    for (const p of platforms) {
      const scope: TeamScope = opts.scope === "project" || opts.scope === "global"
        ? opts.scope
        : await askScope(p);

      const adapter = getAdapter(p);
      adapter.writeTeam({
        name: spec.name,
        members: spec.agents.map((a) => ({ name: a.name, role: a.role, soul: a.soul })),
      }, scope);

      console.log(`Applied "${spec.name}" (${spec.agents.length} agents) to ${p} (${scope} scope).`);
    }
  });

// --- diff ---
program
  .command("diff")
  .description("Show differences between local agent-team.yaml and relay")
  .action(async () => {
    const config = loadConfig();
    if (!config?.teamId) {
      console.error("Not initialized or no team ID. Run `teambridge init` first.");
      process.exit(1);
    }

    const kp = loadKeypair();
    if (!kp) {
      console.error("No keypair found.");
      process.exit(1);
    }

    let localSpec: TeamSpec;
    try {
      localSpec = readTeamSpec();
    } catch (err) {
      console.error((err as Error).message);
      process.exit(1);
    }

    const client = new RelayClient(config.relay, kp.privateKey, config.token);
    try {
      const remoteTeam = await client.getTeam(config.teamId);

      const localAgents = new Map(localSpec.agents.map((a) => [a.name, a.role]));
      const remoteAgents = new Map(remoteTeam.members.map((m) => [m.name, m.role]));

      let hasDiff = false;

      if (localSpec.name !== remoteTeam.name) {
        console.log(`  team name: "${localSpec.name}" (local) vs "${remoteTeam.name}" (relay)`);
        hasDiff = true;
      }

      // Agents only in local
      for (const [name, role] of localAgents) {
        if (!remoteAgents.has(name)) {
          console.log(`  + ${name} (${role}) — local only`);
          hasDiff = true;
        } else if (remoteAgents.get(name) !== role) {
          console.log(`  ~ ${name}: role "${role}" (local) vs "${remoteAgents.get(name)}" (relay)`);
          hasDiff = true;
        }
      }

      // Agents only on relay
      for (const [name, role] of remoteAgents) {
        if (!localAgents.has(name)) {
          console.log(`  - ${name} (${role}) — relay only`);
          hasDiff = true;
        }
      }

      if (!hasDiff) {
        console.log("No differences between local and relay.");
      }
    } catch (err) {
      console.error("Failed to fetch relay state:", err);
      process.exit(1);
    }
  });

// --- sync ---
program
  .command("sync")
  .description("Sync with relay server")
  .action(async () => {
    const config = loadConfig();
    if (!config) {
      console.error("Not initialized. Run `teambridge init` first.");
      process.exit(1);
    }
    if (!config.teamId) {
      console.error("No team ID configured.");
      process.exit(1);
    }

    const kp = loadKeypair();
    if (!kp) {
      console.error("No keypair found.");
      process.exit(1);
    }

    const platform = primaryPlatform(config.platform);
    const adapter = getAdapter(platform);
    const client = new RelayClient(config.relay, kp.privateKey, config.token);

    try {
      const hashes = adapter.getHashes();
      const result = await client.sync(platform, hashes);

      const entries = Object.entries(result.changes);
      if (entries.length > 0) {
        let applied = 0;
        for (const [key, remoteChange] of entries) {
          const localContent = adapter.readFile(key);
          const merged = resolveChange(key, localContent, remoteChange, 0);
          if (merged.warning) {
            console.warn(`  WARN: ${merged.warning}`);
          }
          if (merged.action !== "keep-local") {
            adapter.writeFile(key, merged.content);
            applied++;
          }
        }
        console.log(`Applied ${applied} of ${entries.length} change(s) from relay.`);
      } else {
        console.log("Already up to date.");
      }
    } catch (err) {
      console.error("Sync failed:", err);
      process.exit(1);
    }
  });

// --- push ---
program
  .command("push")
  .description("Push local memory to relay")
  .action(async () => {
    const config = loadConfig();
    if (!config) {
      console.error("Not initialized. Run `teambridge init` first.");
      process.exit(1);
    }
    if (!config.teamId) {
      console.error("No team ID configured.");
      process.exit(1);
    }

    const kp = loadKeypair();
    if (!kp) {
      console.error("No keypair found.");
      process.exit(1);
    }

    const platform = primaryPlatform(config.platform);
    const adapter = getAdapter(platform);
    const client = new RelayClient(config.relay, kp.privateKey, config.token);

    try {
      const knowledge = adapter.readKnowledge();
      if (!knowledge) {
        console.log("No team knowledge to push.");
        return;
      }

      await client.push(platform, {
        type: "team-knowledge",
        content: knowledge,
      });
      console.log("Pushed team knowledge.");
    } catch (err) {
      console.error("Push failed:", err);
      process.exit(1);
    }
  });

// --- status ---
program
  .command("status")
  .description("Show current configuration and sync state")
  .action(async () => {
    const config = loadConfig();
    if (!config) {
      console.log("TeamBridge is not initialized.");
      console.log("Run `teambridge init` to get started.");
      return;
    }

    console.log("TeamBridge Status:");
    console.log(`  Platform: ${config.platform}`);
    console.log(`  Relay:    ${config.relay}`);
    console.log(`  Token:    ${config.token}`);
    if (config.teamId) {
      console.log(`  Team ID:  ${config.teamId}`);
    }

    // Show local team info from agent-team.yaml
    try {
      const spec = readTeamSpec();
      console.log(`\nLocal Team: ${spec.name}`);
      console.log("  Agents:");
      for (const agent of spec.agents) {
        console.log(`    - ${agent.name}: ${agent.role}`);
      }
    } catch {
      console.log("\nNo agent-team.yaml found in current directory.");
    }

    // Show relay state if configured
    if (config.teamId) {
      const kp = loadKeypair();
      if (kp) {
        const client = new RelayClient(config.relay, kp.privateKey, config.token);
        try {
          const remoteTeam = await client.getTeam(config.teamId);
          console.log(`\nRelay Team: ${remoteTeam.name}`);
          console.log("  Members:");
          for (const m of remoteTeam.members) {
            console.log(`    - ${m.name}: ${m.role} (${m.platform})`);
          }
        } catch {
          console.log("\nRelay unreachable.");
        }
      }
    }
  });

// --- daemon ---
program
  .command("daemon")
  .description("Start the background sync daemon")
  .option("--poll-interval <ms>", "Poll interval in milliseconds", "120000")
  .action(async (opts: { pollInterval: string }) => {
    const config = loadConfig();
    if (!config) {
      console.error("Not initialized. Run `teambridge init` first.");
      process.exit(1);
    }

    const kp = loadKeypair();
    if (!kp) {
      console.error("No keypair found.");
      process.exit(1);
    }

    const platform = primaryPlatform(config.platform);
    const adapter = getAdapter(platform);
    const client = new RelayClient(config.relay, kp.privateKey, config.token);

    const { startDaemon } = await import("./daemon.js");
    const daemon = startDaemon({
      adapter,
      client,
      platform,
      pollInterval: parseInt(opts.pollInterval, 10),
    });

    // Graceful shutdown
    const shutdown = () => {
      daemon.stop();
      process.exit(0);
    };
    process.on("SIGINT", shutdown);
    process.on("SIGTERM", shutdown);
  });

program.parse();
