import * as fs from "node:fs";
import * as crypto from "node:crypto";
import { watch } from "chokidar";
import type { PlatformAdapter } from "./adapters/base.js";
import type { RelayClient, SyncChange } from "./relay-client.js";
import { resolveChange } from "./merge.js";
import { readTeamSpec } from "./team-spec.js";

const POLL_INTERVAL_MS = 2 * 60 * 1000; // 2 minutes

function hashContent(content: string): string {
  return crypto.createHash("sha256").update(content).digest("hex").slice(0, 16);
}

export interface DaemonOptions {
  adapter: PlatformAdapter;
  client: RelayClient;
  platform: string;
  pollInterval?: number;
}

export function startDaemon(opts: DaemonOptions): { stop: () => void } {
  const { adapter, client, platform } = opts;
  const pollInterval = opts.pollInterval ?? POLL_INTERVAL_MS;

  // Cache of hashes for files we've written ourselves (self-trigger prevention)
  const writtenHashes = new Map<string, string>();

  // Last known hashes for change detection
  let lastHashes: Record<string, string> = adapter.getHashes();

  // Timestamp of last successful sync with relay
  let lastSyncTimestamp = Math.floor(Date.now() / 1000);

  // Track local modification timestamps per key
  const localModTimes = new Map<string, number>();

  let stopped = false;

  function log(msg: string): void {
    const ts = new Date().toISOString().slice(11, 19);
    console.log(`[${ts}] ${msg}`);
  }

  function warn(msg: string): void {
    const ts = new Date().toISOString().slice(11, 19);
    console.warn(`[${ts}] WARN: ${msg}`);
  }

  // Read file content and compute hash, returns null if file doesn't exist
  function readAndHash(filePath: string): { content: string; hash: string } | null {
    try {
      const content = fs.readFileSync(filePath, "utf-8");
      return { content, hash: hashContent(content) };
    } catch {
      return null;
    }
  }

  // Push local changes to relay
  async function pushChanges(): Promise<void> {
    const currentHashes = adapter.getHashes();
    const changedFiles: Record<string, string> = {};
    const now = Math.floor(Date.now() / 1000);

    for (const [key, hash] of Object.entries(currentHashes)) {
      if (lastHashes[key] !== hash) {
        const content = adapter.readFile(key);
        if (content !== null) {
          changedFiles[key] = content;
          localModTimes.set(key, now);
        }
      }
    }

    if (Object.keys(changedFiles).length === 0) {
      lastHashes = currentHashes;
      return;
    }

    try {
      const result = await client.sync(platform, currentHashes, changedFiles);
      lastSyncTimestamp = Math.floor(Date.now() / 1000);
      lastHashes = currentHashes;
      applyRemoteChanges(result.changes);
      log(`Pushed ${Object.keys(changedFiles).length} file(s), received ${Object.keys(result.changes).length} change(s).`);
    } catch (err) {
      warn(`Push failed: ${(err as Error).message}`);
    }
  }

  // Apply changes received from the relay using merge strategies
  function applyRemoteChanges(changes: Record<string, SyncChange>): void {
    for (const [key, remoteChange] of Object.entries(changes)) {
      const localContent = adapter.readFile(key);
      const localModTime = localModTimes.get(key) ?? 0;

      const result = resolveChange(key, localContent, remoteChange, localModTime);

      if (result.warning) {
        warn(result.warning);
      }

      if (result.action === "keep-local") {
        continue;
      }

      // Write the resolved content
      adapter.writeFile(key, result.content);
      const hash = hashContent(result.content);
      writtenHashes.set(key, hash);

      // If agent-team.yaml changed, regenerate platform-native agent files
      if (key === "team-spec") {
        try {
          const spec = readTeamSpec();
          adapter.writeTeam({
            name: spec.name,
            members: spec.agents.map((a) => ({ name: a.name, role: a.role, soul: a.soul })),
          });
          log("Regenerated platform-native agent files from updated agent-team.yaml.");
        } catch (err) {
          warn(`Failed to regenerate agent files: ${(err as Error).message}`);
        }
      }

      // Update local mod time to match remote after accepting
      if (result.action === "accept-remote") {
        localModTimes.set(key, remoteChange.updated_at);
      } else {
        // merged — treat as a new local modification
        localModTimes.set(key, Math.floor(Date.now() / 1000));
      }
    }
    // Update lastHashes to include newly written files
    lastHashes = adapter.getHashes();
  }

  // Poll relay for remote changes
  async function pollRelay(): Promise<void> {
    if (stopped) return;

    try {
      const changed = await client.syncCheck(lastSyncTimestamp);
      if (!changed) return;

      log("Remote changes detected, syncing...");
      const currentHashes = adapter.getHashes();
      const result = await client.sync(platform, currentHashes);
      lastSyncTimestamp = Math.floor(Date.now() / 1000);
      lastHashes = currentHashes;

      const changeCount = Object.keys(result.changes).length;
      if (changeCount > 0) {
        applyRemoteChanges(result.changes);
        log(`Applied ${changeCount} remote change(s).`);
      }
    } catch (err) {
      warn(`Poll failed (relay unreachable?): ${(err as Error).message}`);
    }
  }

  // File watcher
  const watchPaths = adapter.watchPaths().filter((p) => {
    const dir = fs.existsSync(p) ? p : undefined;
    return dir !== undefined || fs.existsSync(p.replace(/[/][^/]+$/, ""));
  });

  const watcher = watch(watchPaths, {
    ignoreInitial: true,
    awaitWriteFinish: { stabilityThreshold: 300, pollInterval: 100 },
  });

  watcher.on("change", (filePath: string) => {
    const file = readAndHash(filePath);
    if (!file) return;

    // Check if this was a self-triggered write
    for (const [key, cachedHash] of writtenHashes) {
      if (file.hash === cachedHash) {
        writtenHashes.delete(key);
        return;
      }
    }

    log(`File changed: ${filePath}`);
    void pushChanges();
  });

  watcher.on("add", (filePath: string) => {
    log(`File added: ${filePath}`);
    void pushChanges();
  });

  // Poll interval
  const pollTimer = setInterval(() => {
    void pollRelay();
  }, pollInterval);

  log(`Daemon started. Watching ${watchPaths.length} path(s), polling every ${pollInterval / 1000}s.`);
  log(`Paths: ${watchPaths.join(", ")}`);

  // Initial sync
  void pollRelay();

  return {
    stop() {
      stopped = true;
      clearInterval(pollTimer);
      void watcher.close();
      log("Daemon stopped.");
    },
  };
}
