import * as fs from "node:fs";
import * as path from "node:path";
import { parse, stringify } from "yaml";

const TEAM_FILE = "agent-team.yaml";
const NAME_PATTERN = /^[a-z0-9][a-z0-9_-]*$/;

export interface AgentSpec {
  name: string;
  role: string;
  soul?: string;
}

export interface TeamSpec {
  name: string;
  agents: AgentSpec[];
}

export interface ValidationError {
  path: string;
  message: string;
}

export function validateTeamSpec(data: unknown): ValidationError[] {
  const errors: ValidationError[] = [];

  if (data == null || typeof data !== "object") {
    errors.push({ path: "", message: "spec must be an object" });
    return errors;
  }

  const spec = data as Record<string, unknown>;

  // name
  if (typeof spec.name !== "string" || spec.name.length === 0) {
    errors.push({ path: "name", message: "name is required and must be a non-empty string" });
  } else if (!NAME_PATTERN.test(spec.name)) {
    errors.push({
      path: "name",
      message: "name must be lowercase alphanumeric with hyphens/underscores, starting with a letter or digit",
    });
  }

  // agents
  if (!Array.isArray(spec.agents)) {
    errors.push({ path: "agents", message: "agents must be an array" });
    return errors;
  }

  if (spec.agents.length === 0) {
    errors.push({ path: "agents", message: "agents must contain at least one agent" });
  }

  const names = new Set<string>();

  for (let i = 0; i < spec.agents.length; i++) {
    const agent = spec.agents[i] as Record<string, unknown> | null;
    const prefix = `agents[${i}]`;

    if (agent == null || typeof agent !== "object") {
      errors.push({ path: prefix, message: "each agent must be an object" });
      continue;
    }

    if (typeof agent.name !== "string" || agent.name.length === 0) {
      errors.push({ path: `${prefix}.name`, message: "agent name is required" });
    } else if (!NAME_PATTERN.test(agent.name)) {
      errors.push({
        path: `${prefix}.name`,
        message: "agent name must be lowercase alphanumeric with hyphens/underscores",
      });
    } else if (names.has(agent.name)) {
      errors.push({ path: `${prefix}.name`, message: `duplicate agent name: ${agent.name}` });
    } else {
      names.add(agent.name);
    }

    if (typeof agent.role !== "string" || agent.role.length === 0) {
      errors.push({ path: `${prefix}.role`, message: "agent role is required" });
    }

    if (agent.soul !== undefined && typeof agent.soul !== "string") {
      errors.push({ path: `${prefix}.soul`, message: "soul must be a string if provided" });
    }
  }

  return errors;
}

export function readTeamSpec(dir?: string): TeamSpec {
  const filePath = path.resolve(dir ?? process.cwd(), TEAM_FILE);

  if (!fs.existsSync(filePath)) {
    throw new Error(`${TEAM_FILE} not found in ${path.dirname(filePath)}`);
  }

  const raw = fs.readFileSync(filePath, "utf-8");
  let data: unknown;
  try {
    data = parse(raw);
  } catch (err) {
    throw new Error(`Failed to parse ${TEAM_FILE}: ${(err as Error).message}`);
  }

  const errors = validateTeamSpec(data);
  if (errors.length > 0) {
    const details = errors.map((e) => `  ${e.path}: ${e.message}`).join("\n");
    throw new Error(`Invalid ${TEAM_FILE}:\n${details}`);
  }

  const spec = data as Record<string, unknown>;
  return {
    name: spec.name as string,
    agents: (spec.agents as Record<string, unknown>[]).map((a) => ({
      name: a.name as string,
      role: a.role as string,
      ...(a.soul !== undefined ? { soul: a.soul as string } : {}),
    })),
  };
}

export function writeTeamSpec(spec: TeamSpec, dir?: string): void {
  const errors = validateTeamSpec(spec);
  if (errors.length > 0) {
    const details = errors.map((e) => `  ${e.path}: ${e.message}`).join("\n");
    throw new Error(`Invalid team spec:\n${details}`);
  }

  const filePath = path.resolve(dir ?? process.cwd(), TEAM_FILE);
  const content = stringify(spec, { lineWidth: 0 });
  fs.writeFileSync(filePath, content);
}
