import * as fs from "node:fs";
import * as path from "node:path";
import * as os from "node:os";

export interface GlobalTeam {
  teamId: string;
  platforms: string[];
  noSync?: boolean;
}

export interface TeamrcConfig {
  token: string;
  relay: string;
  trustedRelays?: string[];
  account?: {
    email: string;
  };
  machineName?: string;
  globalTeam?: GlobalTeam;
  /** @deprecated Use globalTeam.platforms or .teamrc.yaml platforms instead */
  platform?: string;
  /** @deprecated Use globalTeam.teamId or .teamrc.yaml teamId instead */
  teamId?: string;
  /** @deprecated Use globalTeam.noSync or .teamrc.yaml noSync instead */
  noSync?: boolean;
}

function getConfigDir(): string {
  return path.join(os.homedir(), ".teamrc");
}

function getConfigPath(): string {
  return path.join(getConfigDir(), "config.json");
}

export function loadConfig(): TeamrcConfig | null {
  const configPath = getConfigPath();
  if (!fs.existsSync(configPath)) {
    return null;
  }
  try {
    const raw = fs.readFileSync(configPath, "utf-8");
    return JSON.parse(raw) as TeamrcConfig;
  } catch {
    return null;
  }
}

export function saveConfig(config: TeamrcConfig): void {
  const dir = getConfigDir();
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  }
  fs.writeFileSync(getConfigPath(), JSON.stringify(config, null, 2), { mode: 0o600 });
}

export function detectPlatforms(): string[] {
  const home = os.homedir();
  const cwd = process.cwd();
  const platforms: string[] = [];

  const signals: Record<string, () => boolean> = {
    "claude-code": () => fs.existsSync(path.join(home, ".claude")),
    "cursor": () => fs.existsSync(path.join(cwd, ".cursor")),
    "codex": () => fs.existsSync(path.join(home, ".codex")) || fs.existsSync(path.join(cwd, ".codex")),
    "gemini": () => fs.existsSync(path.join(cwd, ".gemini")) || fs.existsSync(path.join(home, ".gemini")),
    "openclaw": () => fs.existsSync(path.join(home, ".openclaw")),
    "copilot": () => fs.existsSync(path.join(cwd, ".github")),
    "amazon-q": () => fs.existsSync(path.join(home, ".amazonq")) || fs.existsSync(path.join(cwd, ".amazonq")),
    "windsurf": () => fs.existsSync(path.join(cwd, ".windsurf")),
    "cline": () => fs.existsSync(path.join(cwd, ".clinerules")) || fs.existsSync(path.join(cwd, ".cline")),
  };

  for (const [name, check] of Object.entries(signals)) {
    if (check()) platforms.push(name);
  }
  return platforms;
}

export function getRelayUrl(overrideUrl?: string): string {
  if (overrideUrl) {
    return overrideUrl;
  }
  const envUrl = process.env["TEAMRC_RELAY"];
  if (envUrl) {
    return envUrl;
  }
  const config = loadConfig();
  if (config?.relay) {
    return config.relay;
  }
  return "http://localhost:4000";
}
